SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `department` (`department`) VALUES
('IT Department'),
('Marketing Department'),
('HR Department'),
('Finance Department');

CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `department_id` int(11) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `birthday` date NOT NULL,
  `role` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_employee_department` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`)
);

INSERT INTO `employee` (`name`, `email`, `mobile`, `password`, `department_id`, `address`, `birthday`, `role`) VALUES
('Mula', 'mula@gmail.com', '0813141712', '12345', 1, 'Pretoria', '2000-10-15', 2),
('Admin', 'admin@gmail.com', '', 'admin', 2, '', '0000-00-00', 1),
('Mike', 'mike@gmail.com', '0715079768', '12345', 1, 'JHB', '1992-07-31', 2);

CREATE TABLE `leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `leave_id` int(11) NOT NULL,
  `leave_from` date NOT NULL,
  `leave_to` date NOT NULL,
  `leave_description` text NOT NULL,
  `leave_status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_leave_employee` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`)
);

INSERT INTO `leave` (`employee_id`, `leave_id`, `leave_from`, `leave_to`, `leave_description`, `leave_status`) VALUES
(1, 3, '2023-09-17', '2023-09-25', 'Sick Leave', 1),
(3, 2, '2023-09-29', '2023-10-02', 'Paid Leave', 3),
(3, 3, '2023-10-15', '2023-10-20', 'Causal Leave', 2);

CREATE TABLE `leave_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `leave_type` (`leave_type`) VALUES
('Casual Leave'),
('Paid Leave'),
('Sick Leave'),
('Family Leave'),
('Other');

COMMIT;
